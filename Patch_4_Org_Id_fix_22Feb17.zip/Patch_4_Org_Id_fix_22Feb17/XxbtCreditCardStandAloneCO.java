package xxbt.oracle.apps.iby.creditcard.setup.webui;

import com.sun.java.util.collections.HashMap;
import java.io.Serializable;
import oracle.apps.ar.hz.components.util.server.HzPuiServerUtil;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAPageLayoutBean;
import oracle.apps.fnd.framework.webui.beans.layout.OATableLayoutBean;
import oracle.apps.fnd.framework.webui.beans.message.*;
import oracle.apps.fnd.framework.webui.beans.nav.OALinkBean;
import oracle.cabo.ui.UIConstants;

public class XxbtCreditCardStandAloneCO extends OAControllerImpl
{
  public XxbtCreditCardStandAloneCO()
  {
  }

  public void processRequest(OAPageContext oapagecontext, OAWebBean oawebbean)
  {
      super.processRequest(oapagecontext, oawebbean);
      System.out.println("XxbtCreditCardStandAloneCO.XXBTLog:Entering xxbtCreditCardStandAloneCO.ProcessRequest");
      OAApplicationModule oaapplicationmodule = oapagecontext.getApplicationModule(oawebbean);
      OAPageLayoutBean oapagelayoutbean = oapagecontext.getPageLayoutBean();
      OATableLayoutBean oatablelayoutbean = (OATableLayoutBean)oapagelayoutbean.findChildRecursive("addrTableLayout");
      if(oatablelayoutbean != null)
          oatablelayoutbean.setHAlign("center");
      String payerPartyId = oapagecontext.getRenderingContext().getServletRequest().getParameter("IbyPayerPartyId");//oapagecontext.getParameter("IbyPayerPartyId");
      String custAccountId =oapagecontext.getRenderingContext().getServletRequest().getParameter("IbyCustAccountId");// oapagecontext.getParameter("IbyCustAccountId");
      if(oapagecontext.isLoggingEnabled(1))
          oapagecontext.writeDiagnostics(this, (new StringBuilder()).append("IbyCustAccountId:").append(custAccountId).toString(), 1);
      String custAccountSiteId =oapagecontext.getRenderingContext().getServletRequest().getParameter("IbyCustAccountSiteId");/// oapagecontext.getParameter("IbyCustAccountSiteId");
      
      String partyName = oapagecontext.getRenderingContext().getServletRequest().getParameter("IbyPartyName");
      if(partyName != null && !"".equals(partyName.trim()))
          oapagecontext.putTransactionValue("IbyPayerName", partyName);
      else
          partyName = (String)oapagecontext.getTransactionValue("IbyPayerName");

      String returnLink = oapagecontext.getRenderingContext().getServletRequest().getParameter("IbyReturnlink");
      if(returnLink == null)
          returnLink = oapagecontext.getRenderingContext().getServletRequest().getParameter("IbyReturnLink");

      String returnLinkName =oapagecontext.getRenderingContext().getServletRequest().getParameter("IbyReturnLinkLabel");
      String orgId =oapagecontext.getRenderingContext().getServletRequest().getParameter("XXBT_ORG_ID");
      oapagecontext.putTransactionValue("XXBT_ORG_ID", orgId);

      OAFormValueBean oaformvaluebean = (OAFormValueBean)oapagelayoutbean.findChildRecursive("PagePartyId");
      oaformvaluebean.setValue(payerPartyId);
      OAMessageStyledTextBean oamessagestyledtextbean = (OAMessageStyledTextBean)oapagelayoutbean.findChildRecursive("CardHolder");
      oamessagestyledtextbean.setText(partyName);
      OAMessageTextInputBean oamessagetextinputbean = (OAMessageTextInputBean)oapagelayoutbean.findChildRecursive("CCNumber");
      if(oamessagetextinputbean != null)
          oamessagetextinputbean.setAttributeValue(UIConstants.NO_AUTO_COMPLETE_ATTR, Boolean.TRUE);
      OAMessageTextInputBean oamessagetextinputbean1 = (OAMessageTextInputBean)oapagelayoutbean.findChildRecursive("NameonCard");
      if(oamessagetextinputbean1 != null)
          oamessagetextinputbean1.setAttributeValue(UIConstants.NO_AUTO_COMPLETE_ATTR, Boolean.TRUE);
      if(payerPartyId != null)
          oapagecontext.putTransactionValue("IbyPayerPartyId", payerPartyId);
      if(returnLink == null)
          returnLink = (String)oapagecontext.getTransactionValue("IbyReturnLink");
      else
          oapagecontext.putTransactionValue("IbyReturnLink", returnLink);

      if(returnLinkName == null)
          returnLinkName = (String)oapagecontext.getTransactionValue("IbyReturnLinkLabel");
      else
          oapagecontext.putTransactionValue("IbyReturnLinkLabel", returnLinkName);

      oracle.apps.fnd.common.MessageToken amessagetoken[] = null;
      OAPageLayoutBean oapagelayoutbean1 = oapagecontext.getPageLayoutBean();
          String s14 = oapagecontext.getMessage("IBY", "IBY_CREATE_CREDITCARD_TITLE", amessagetoken);
          oapagelayoutbean1.setTitle(s14);
          oapagelayoutbean1.setWindowTitle(s14);

      String newSiteId = oapagecontext.getParameter("IbyNewSiteId");
      if("Y".equals(oapagecontext.getParameter("IbyNewAddress")))
      {
          oapagecontext.putParameter("IbyNewAddress", "");
          String newFormattedAddress = oapagecontext.getParameter("IbyNewFormattedAddress");
          OAMessageLovInputBean oamessagelovinputbean = (OAMessageLovInputBean)oawebbean.findChildRecursive("Address");
          if(oamessagelovinputbean != null)
              oamessagelovinputbean.setText(newFormattedAddress);
          OAFormValueBean oaformvaluebean1 = (OAFormValueBean)oapagelayoutbean.findChildRecursive("PagePartySiteId");
          if(oaformvaluebean1 != null)
              oaformvaluebean1.setValue(newSiteId);
          return;
      }
      System.out.println("XxbtCreditCardStandAloneCO.XXBTLog:Leaving xxbtCreditCardStandAloneCO.ProcessRequest");
  }

  public static void main(String[] args)
  {
    XxbtCreditCardStandAloneCO xxbtCreditCardStandAloneCO = new XxbtCreditCardStandAloneCO();
  }
}

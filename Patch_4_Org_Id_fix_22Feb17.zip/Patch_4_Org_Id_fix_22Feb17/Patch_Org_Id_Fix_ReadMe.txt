
Org_Id fix - Patch Instructions.
======================================
This Patch consists of fix to the Org_id issue that a customer can face when on a Multi-App Node env, and when trying to create a new Payment Method from OM form via the OAF screen.
To fix this error, apply this patch by following the below Instructions.

1> FTP all the 6 files (*.java and *.class) to the Unix stage/patch folder.
2> Copy the 3 java files to the $XXBT_TOP/src/... corresponding location. The file names are ...
	XxbtCreditCardAMImpl.java
	XxbtCreditCardCO.java
	XxbtCreditCardStandAloneCO.java
	
Note: these files will be in sub-folders under the "src" folder. Please make a back-up of the original files before copying the new ones.

3> Copy the 3 Class files to the following Locations ... (NOTE: you may want to back-up the existing files before replacing new one. 
								Also please MOVE the backed-up files to another folder outside of the CLASSPATH folder to avoid conflict.)
	$JAVA_TOP/xxbt/oracle/app/iby/creditcard/setup/server/XxbtCreditCardAMImpl.class
	$JAVA_TOP/xxbt/oracle/app/iby/creditcard/setup/webui/XxbtCreditCardCO.class
	$JAVA_TOP/xxbt/oracle/app/iby/creditcard/setup/webui/XxbtCreditCardStandAloneCO.class

4> Login to Oracle Forms and Open the Order Management Super User -SUPRA responsibility. 
	-- Open the Sales ORder Form where we have the Personalizations.
	-- Navigate to Help > Diagnostics > Custom Code > Personalize
	-- Scroll down to the Personalization "Seq = 99.6" "Description = BT: Launch BT Vaulted Pay Method Capture Form"
	-- Open the Actions Tab.
	-- Navigate to the 2nd Action viz: "Seq = 10", "Type = Builtin", "Description = Launch Tokenize CC OAF Page"
		-- For this entry ... REPLACE / Paste the "Argument field with the below Value within Quotes" [NOTE - DO NOT COPY QUOTES]
			"=${ps.xxbt_hop_url_path.value}||'?page=/xxbt/oracle/apps/iby/creditcard/setup/webui/xxBtCreditCardCreateBTPG&IbyPartyName='||:ORDER.INVOICE_TO_CUSTOMER_NAME||'&IbyPayerId=&IbyCustAccountId='||:ORDER.INVOICE_TO_CUSTOMER_ID||'&IbyPayerPartyId='||${var.XXPARTY_ID.value}||'&IbyPaymentFlow=FUNDS_CAPTURE&XXBT_SOURCE=OM&IbyPaymentFunction=CUSTOMER_PAYMENT&IbyCustAcctNumber=&XXBT_STANDALONE_MODE=Y&XXBT_ORG_ID='||:ORDER.ORG_ID||'&PagePartySiteId='||${var.XXPARTY_SITE_ID.value}||'&R12_REF_ID='||:ORDER.HEADER_ID"
		-- Press Validate button to Verify the syntax.
		-- NOTE: You will need to have an Order queried and open on the FORM before you can press Validate.
		-- Make sure the Validate gives you a valid String.
		-- Press APPLY and Save the Personalization.
5> Logout of the FORM.
6> Bounce the Middletier.
7> DONE
8> Test the usecase to make sure the Issue is Resolved 

=== END ===


package xxbt.oracle.apps.iby.creditcard.setup.webui;

import java.io.Serializable;

import java.sql.CallableStatement;
import java.util.Enumeration;

import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OABodyBean;
import oracle.apps.fnd.framework.webui.beans.OARawTextBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAPageLayoutBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

public class XxbtCreditCardCO extends OAControllerImpl
{
    public static final String ccNumberID = "xxbtCCNumber";
    public static final String ccCvvID = "xxbtCCCVV";
    public static final String ccExpDtID = "xxbtCCExpDate";
    public static final String STANDALONE_MODE = "XXBT_STANDALONE_MODE";   
    public static final String customerVaultedProfile = "XXBT_R12_VAULT_CUSTOMERS";
    public static final String IBY_PAYER_PARTY_ID = "IbyPayerPartyId";//IbyPayerPartyId
    public static final String IBY_PARTY_ID = "IbyPartyId";
    public static final String IBY_PAGE_PARTY_ID = "PagePartyId";
    public static final String IBY_CUST_ACCOUNT_ID = "IbyCustAccountId";//done
    public static final String IBY_ORG_ID = "IbyOrgId";
    public static final String IBY_INSTRUMENT_CREATED_EVENT = "IbyInstrumentCreated";
    public static final String IBY_CREATE_CARD_EVENT = "IbyCreateCreditCard";
    public static final String IBY_UPDATE_CARD_EVENT = "IbyUpdateCreditCard";
    public static final String IBY_PARTY_SITE_ID = "IbyPartySiteId";
    public static final String IBY_ACCOUNT_SITE_ID = "IbyAccountSiteId";
    public static final String IBY_ACCOUNT_SITE_USE_ID = "IbyAccountSiteUseId";
    public static final String IBY_INSTRUMENT_ID = "IbyInstrumentId";
    public static final String IBY_INSTRID = "InstrId";
    public static final String IBY_INSTRUMENT_TYPE = "IbyInstrumentType";//IbyInstrumentType - CREDITCARD
    public static final String XXBT_CARD_TYPE = "CardIssuerCode";
    public static final String IBY_PAGE_PARTY_SITE_ID = "PagePartySiteId";
    public static final String R12_REF_ID = "R12_REF_ID";
    public static final String R12_REF_SOURCE = "R12_REF_SOURCE";

   public static final String htmlStr = " <tr id=\"xxbtCCNumber__xc_\">" + 
   "                                                   <td align=\"right\" nowrap width=\"50%\"><span class=\"xc\">* Number</span></td>" + 
   "                                                   <td width=\"12\"><img src=\"/OA_HTML/cabo/images/swan/t.gif\" width=\"12\"></td>" + 
   "                                                   <td valign=\"top\" width=\"50%\">" +
   "                                                   <div id=\"xxbtCCNumber\" class=\"x4\" style=\"width:150px;height:20px;border-style:inset;border-color:#c9cbd3;border-width:1px;\" onchange=\"\" name=\"xxbtCCNumber\" size=\"25\" type=\"text\" maxlength=\"30\"></div>" + 
   "                                                   <img src=\"/OA_HTML/cabo/images/swan/t.gif\" width=\"5\"></td>" + 
   "                                                </tr>" + 
   "                                                <tr id=\"xxbtCCExpDate__xc_\">" + 
   "                                                   <td align=\"right\" nowrap width=\"50%\"><span class=\"xc\">* Expiration Date (mm/yy)</span></td>" + 
   "                                                   <td width=\"12\"><img src=\"/OA_HTML/cabo/images/swan/t.gif\" width=\"12\"></td>" + 
   "                                                   <td valign=\"top\" width=\"50%\">" + 
   "                                                   <div id=\"xxbtCCExpDate\" class=\"x4\" style=\"width:100px;height:20px;border-style:inset;border-color:#c9cbd3;border-width:1px;\"  onchange=\"\" name=\"xxbtCCExpDate\" size=\"40\" type=\"text\" maxlength=\"240\"></div>" + 
   "                                                   <img src=\"/OA_HTML/cabo/images/swan/t.gif\" width=\"5\"></td>" + 
   "                                                </tr>" + 
   "                                       <input type=\"hidden\" id=\"btjson\" name=\"btjson\" >";

    public static final String applyBtnHtml = "<p><input id=\"xxbtSubmitPay\" class=\"x7n\" style=\"background-image:url(/OA_HTML/cabo/images/swan/btn-bg1.gif)\" type=\"submit\" value=\"Apply\"></p>";  

    public static final String javaScriptStr = " function btreeJS(btreeStr)" +
    "{ "+ //alert(btreeStr);" +
            " braintree.setup(  " +
            "            btreeStr,  " +
            "            'custom',{id:'DefaultFormName' ,  " +
            "                hostedFields:{  " +
            "                    styles: {" +
            "                        \"input\": {" +
            "                            \"font-family\":\"Tahoma,Arial,Helvetica,Geneva,sans-serif\","+
            "                            \"font-size\": \"9pt\"," +
            "                            \"color\": \"#3c3c3c\"" +
            "                        }," +
            "                        \".number\": {" +
            "                            \"font-family\": \"monospace\"" +
            "                        }," +
            "                        \":focus\": {" +
            "                            \"color\": \"blue\"" +
            "                        }," +
            "                        \".valid\": {" +
            "                            \"color\": \"green\"" +
            "                        }," +
            "                        \".invalid\": {" +
            "                            \"color\": \"red\"" +
            "                        }," +
            "                        \"@media screen and (max-width: 700px)\": {" +
            "                            \"input\": {" +
            "                            \"font-family\":\"Tahoma,Arial,Helvetica,Geneva,sans-serif\","+
            "                            \"font-size\": \"9pt\"," +
            "                            \"color\": \"#3c3c3c\"" +
            "                            }" +
            "                        }" +
            "                    },"+
            "                    number: {  " +
            "                        selector: \"#xxbtCCNumber\"  " +
            "                    },  " +
            "                     expirationDate: {  " +
            "                        selector: \"#xxbtCCExpDate\"  " +
            "                    }  " +
            "                },  " +
            "                onPaymentMethodReceived: function (obj) {  " +
//            "                    alert(JSON.stringify(obj));" +
            "      document.getElementById(\"btjson\").value=JSON.stringify(obj);" +
//            "      alert(document.getElementById(\"btjson\").value);" +
            "      submitForm('DefaultFormName',1,{'_FORM_SUBMIT_BUTTON':'submitButton',event:'IbyInstrumentCreated',source:'Apply'});" +
            //"      submitForm('DefaultFormName',1,{'evtSrcRowIdx':'','evtSrcRowId':'',event:'IbyInstrumentCreated',source:'Apply'});" +  //-- frm 12.2.4 code-VK
            "}})"+
            ";}";

  public static final String btreeLib = "script/braintree.js";

  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    System.out.println("XxbtCreditCardCO.processRequest: Entering xxbtCreditCardCO.ProcessRequest ...");
    
    //listPageContextParams(pageContext,"PR");
    this.debugLog(pageContext, "XXBT: Inside processRequest Method of XxbtCreditCardCO.class...");

    Enumeration enums = pageContext.getApplicationModule(webBean).getOADBTransaction().getValueNames();
    String so_org_id = null;
    while(enums.hasMoreElements())
    {
      String name = (String)enums.nextElement();
      String value = pageContext.getTransactionValue(name)!=null?pageContext.getTransactionValue(name).toString():"Null";
      this.debugLog(pageContext,"TR:"+name+"-"+value);
      if("XXBT_ORG_ID".equals(name)){
          so_org_id = value;
      }
    }
    
    //Continue only if XXBT_RENDER_HOSTED is y or Vaulted profile is y 
    if(!renderXXBTCustomization(pageContext, webBean))
    {
      debugLog(pageContext, "Rendering..false");
      if(pageContext.isLoggingEnabled(1)){
          pageContext.writeDiagnostics(this, "Unable to Render Brain Tree Personalization as the XXBT_RENDER_HOSTED is not Y and Vaulted profile is not Y  ", 1);
          debugLog(pageContext,"Unable to Render Brain Tree Personalization as the XXBT_RENDER_HOSTED is not Y and Vaulted profile is not Y ");
      }
      return;
    }

    this.setXXBTTransactionValues(pageContext);
    if("Y".equals(isStandAloneMode(pageContext)) && so_org_id != null){
        pageContext.putTransactionValue("XXBT_ORG_ID", so_org_id);
    }
    
//    String event = pageContext.getParameter("event");
    String event = (String)(pageContext.getTransactionValue(IBY_UPDATE_CARD_EVENT)==null?pageContext.getParameter("event"):pageContext.getTransactionValue(IBY_UPDATE_CARD_EVENT));
    
    if(IBY_UPDATE_CARD_EVENT.equals(event))
    {
      pageContext.putTransactionValue(IBY_UPDATE_CARD_EVENT, IBY_UPDATE_CARD_EVENT);    
      this.debugLog(pageContext,"in Update...returning....");
      return; // in case of update event, only set the transaction values and return.
    }
    //IbyCreateBillAddr, UpdateAddrButton
       
    String custAccountId = (String)pageContext.getTransactionValue("XXBT_CUST_ACCOUNT_ID");
    String orgId = (String)pageContext.getTransactionValue("XXBT_ORG_ID");
    debugLog(pageContext,"Cust Acnt ID:"+custAccountId);
    debugLog(pageContext,"Org ID:"+orgId);
    if(pageContext.isLoggingEnabled(1))
        pageContext.writeDiagnostics(this, (new StringBuilder()).append("custAccountId:").append(custAccountId).toString(), 1);

    if(pageContext.isLoggingEnabled(1))
        pageContext.writeDiagnostics(this, (new StringBuilder()).append("OrgId:").append(orgId).toString(), 1);
    
    if(custAccountId == null || orgId == null)
    {
      if(pageContext.isLoggingEnabled(1)){
          pageContext.writeDiagnostics(this, "Unable to Render Brain Tree Personalization as the Cust Account Id or Org Id are null", 1);
          debugLog(pageContext,"Unable to Render Brain Tree Personalization as the Cust Account Id or Org Id are null");
          throwException("Mandatory data Missing!",null);
      }
      return; //unable to render perz if any of these are null.
    }

    String strBtreeClientToken = null;    
    try 
    {
        strBtreeClientToken = (String)pageContext.getApplicationModule(webBean).invokeMethod("getBTClientToken");
        this.debugLog(pageContext, (new StringBuilder()).append("BtreeClientToken:").append(strBtreeClientToken).toString());
      
        if(strBtreeClientToken==null || "".equals(strBtreeClientToken))
        {
              throwException("Error Retreiving BrainTree Token.",null);//error creating token
        }
    } catch (OAException oaex) 
    {
      oaex.printStackTrace();
      throw oaex;
    }catch (Exception ex) 
    {
      ex.printStackTrace();
      throwException("Error Retreiving BrainTree Token."+ex.getMessage(),null);//error creating token
    } 

    OAPageLayoutBean oapagelayoutbean = pageContext.getPageLayoutBean();
    this.debugLog(pageContext, "Setting Laybout beans...");

    OAWebBean pbnBar = oapagelayoutbean.findChildRecursive("PageButtonBarRN");
    if(pbnBar !=null)
    {
      OARawTextBean payBtnBean = (OARawTextBean)createWebBean(pageContext, "RAW_TEXT", null, null);
      String payBtn = "<input id=\"xxbtSubmitPay\" class=\"x7n\" style=\"background-image:url(/OA_HTML/cabo/images/swan/btn-bg1.gif)\" type=\"submit\" value=\"Apply\">";
      payBtnBean.setText(payBtn);
      pbnBar.addIndexedChild(payBtnBean);
    }

    OARawTextBean rawTextBean = (OARawTextBean)createWebBean(pageContext, "RAW_TEXT", null, null);
    rawTextBean.setText(htmlStr);
    webBean.addIndexedChild(rawTextBean);

    //Add Braintree.js to js library. File Stored in /OA_HTML/script/ location
    pageContext.putJavaScriptLibrary("BTreeGateway",btreeLib);
    pageContext.putJavaScriptFunction("btreeJS",javaScriptStr);
    
    String onLoad = "javascript:btreeJS('"+strBtreeClientToken+"');";
    OABodyBean bodyBean = (OABodyBean) pageContext.getRootWebBean();
    bodyBean.setOnLoad(onLoad);

    //Hide unwanted base fields
     if(!"Y".equals(isStandAloneMode(pageContext)))
     {
         OAWebBean ccNumberBean = oapagelayoutbean.findChildRecursive("CCNumber");
         if(ccNumberBean != null)
         {
           ccNumberBean.setRendered(false);
         }
    
         OAWebBean expDtBean = oapagelayoutbean.findChildRecursive("ExpirationDate");
         if(expDtBean != null)
            expDtBean.setRendered(false);

          OAWebBean applyBtn = oapagelayoutbean.findChildRecursive("Apply");
          if(applyBtn!=null)
            applyBtn.setRendered(false);

         OAWebBean addressBtn = oapagelayoutbean.findChildRecursive("CreateAddrButton");
         if(addressBtn!=null)
         {
             ((OASubmitButtonBean)addressBtn).setServerUnvalidated(true);
             this.debugLog(pageContext, "setting the server unvalidate to true");
         }
          
         OAMessageLovInputBean oamessagelovinputbean1 = (OAMessageLovInputBean)oapagelayoutbean.findChildRecursive("Address");
         if(oamessagelovinputbean1 != null)
         {
                 oamessagelovinputbean1.setRequired("yes");
         }
         
     }
      System.out.println("XxbtCreditCardCO.XXBTLog: Leaving xxbtCreditCardCO.ProcessRequest.");
  }  

  public void processFormData(OAPageContext pageContext, OAWebBean webBean)
  {
      super.processFormData(pageContext, webBean);
      System.out.println("XxbtCreditCardCO.XXBTLog:Entering xxbtCreditCardCO.ProcessFormData");
      //listPageContextParams(pageContext, "PFD");

      if(!renderXXBTCustomization(pageContext, webBean))
         return;
  
      //if event is not create then return
      String event = pageContext.getParameter("event");
      if(IBY_INSTRUMENT_CREATED_EVENT.equals(event)||"Apply".equals(event))
      {      
          debugLog(pageContext,"###PSID In Else..");
          String pagePartyID= (String)pageContext.getParameter(IBY_PAGE_PARTY_SITE_ID);
          debugLog(pageContext,"###PSID In Apply.."+pagePartyID);
          if(pagePartyID==null)
            pagePartyID = (String)pageContext.getParameter("PageAddressId");                  
          if(pagePartyID==null)
            pagePartyID = (String)pageContext.getTransactionValue("XXBT_PARTY_SITE_ID");
          else
            pageContext.putTransactionValue("XXBT_PARTY_SITE_ID",pagePartyID);
          

          String  partySiteId = pagePartyID;
          debugLog(pageContext,"###PSID In finally.."+partySiteId);
          this.debugLog(pageContext,"Pfd: reading instrument ID:"+pageContext.getTransactionValue("XXBT_INSTRUMENT_ID"));

            if(partySiteId==null || "".equals(partySiteId))
            {
              if("Apply".equals(event) && pageContext.getTransactionValue("XXBT_INSTRUMENT_ID")!=null)
              {
                debugLog(pageContext,"###PSID In Apply..");
                partySiteId = (String)pageContext.getApplicationModule(webBean).invokeMethod("getPartySite");
                // Party Site ID null => non vaulted record. So let the standard flow continue and we do not need to interveen
                if(partySiteId == null || "".equals(partySiteId))
                  return; 
                pageContext.putTransactionValue("XXBT_PARTY_SITE_ID", partySiteId);    
              }
              else
              {
                  partySiteId = (String)pagePartyID==null?pageContext.getParameter(IBY_PARTY_SITE_ID):pagePartyID;
                  debugLog(pageContext,"###PSID In Apply.."+partySiteId);
                  pageContext.putTransactionValue("XXBT_PARTY_SITE_ID", partySiteId);    
              }
           }
          if("Y".equals(isStandAloneMode(pageContext)) )
          {
            String nameOnCard =  (String)pageContext.getParameter("NameonCard");
            pageContext.putTransactionValue("XXBT_NAME_ON_CARD", nameOnCard);

            String cardType =  (String)pageContext.getParameter("CardIssuerCode");
            pageContext.putTransactionValue(this.XXBT_CARD_TYPE, cardType);
          }

          debugLog(pageContext,"PFD*****PartySite ID::"+partySiteId);

          //String btJson = pageContext.getParameter("btjson");
          //debugLog(pageContext,"JSon:"+btJson);
          pageContext.writeDiagnostics(this,"XXBTLog:before calling btjson",1);
          String btJson = pageContext.getRenderingContext().getServletRequest().getParameter("btjson");

          
          Serializable[] params ={btJson};
          try 
          {
            String returnStatus = (String)pageContext.getApplicationModule(webBean).invokeMethod("upsertCustomer",params); 
            if(returnStatus !=null && !"S".equals(returnStatus) )
            {
               throwException(returnStatus,null);
            }
          }catch (OAException oaex) 
            {
              throw oaex;
            } catch (Exception ex) 
            {
              throwException("Error Storing Payment Details : "+ex.getMessage(),null);
            }
    }
      System.out.println("XxbtCreditCardCO.XXBTLog:Leaving xxbtCreditCardCO.ProcessFormData");
  }

  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
     
    super.processFormRequest(pageContext, webBean);
    
    System.out.println("XxbtCreditCardCO.XXBTLog:Entering xxbtCreditCardCO.ProcessFormRequest");
    
    //listPageContextParams(pageContext, "PFR");

    if(!renderXXBTCustomization(pageContext, webBean))
       return;
       
    //if event is not create then return
    String event = pageContext.getParameter("event");
    if(event!=null && IBY_INSTRUMENT_CREATED_EVENT.equals(event) && !"Y".equals(isStandAloneMode(pageContext)) )
    {
      try 
      {
        debugLog(pageContext,"Invoking Update CC Details...");
        pageContext.getApplicationModule(webBean).invokeMethod("updateCCDetails");
      } catch (OAException oaex) 
      {
        oaex.printStackTrace();
        throw oaex;
      }catch (Exception ex) 
      {
        ex.printStackTrace();
        throwException("Error Updating Payment Details : "+ex.getMessage(),null);
      }
    }
    if("Y".equals(isStandAloneMode(pageContext))){
        fwdOnSuccess(pageContext,webBean);
    }
    
    System.out.println("XxbtCreditCardCO.XXBTLog:Leaving xxbtCreditCardCO.ProcessFormRequest");
  }

  //helper method to check if the personalization is to be rendered.
  private boolean renderXXBTCustomization(OAPageContext pageContext, OAWebBean webBean)
  {
    this.debugLog(pageContext, "In Render...");

    if("Y".equals(isStandAloneMode(pageContext)))
       return true;
    
    boolean renderCust = false;
    String custVaultedVal = pageContext.getProfile(customerVaultedProfile);
    this.debugLog(pageContext, "In Render custVaultedVal..."+custVaultedVal);
    if(custVaultedVal!=null && "Y".equals(custVaultedVal) ){
      renderCust = true; // return false if the profile value is not yes.
    }

    try 
    {
      this.debugLog(pageContext, "Checking for attribute 30...");
      pageContext.getApplicationModule(webBean).invokeMethod("getPmtRefAttribute");
    } catch (OAException ex) 
    {
      this.debugLog(pageContext, "Exception checking for attribute 30"+ex.getMessage());
      renderCust = false; // return false if the profile value is not yes.
      throw ex;
    }

    return renderCust;
  }

  private void setXXBTTransactionValues(OAPageContext pageContext)
  {
        String orgId = ""+pageContext.getOrgId();
        String partyId = (String)pageContext.getRenderingContext().getServletRequest().getParameter(IBY_PARTY_ID);
        if(partyId==null || "".equals(partyId))
        	partyId = pageContext.getRenderingContext().getServletRequest().getParameter(IBY_PAYER_PARTY_ID);
        if(partyId==null || "".equals(partyId))
        	partyId = pageContext.getRenderingContext().getServletRequest().getParameter(IBY_PAGE_PARTY_ID);
        
       String partySiteId = (String)pageContext.getRenderingContext().getServletRequest().getParameter(IBY_PAGE_PARTY_SITE_ID);       
       if(partySiteId==null || "".equals(partySiteId))
           pageContext.getRenderingContext().getServletRequest().getParameter(IBY_PARTY_SITE_ID);    	   

      String custAccountId = (String)pageContext.getRenderingContext().getServletRequest().getParameter(IBY_CUST_ACCOUNT_ID);
      String custAccountSiteId = (String)pageContext.getRenderingContext().getServletRequest().getParameter(IBY_ACCOUNT_SITE_ID);
      String custAccountSiteUseId = (String)pageContext.getRenderingContext().getServletRequest().getParameter(IBY_ACCOUNT_SITE_USE_ID);
      String instrumentId = (String)pageContext.getRenderingContext().getServletRequest().getParameter(IBY_INSTRID)!=null?pageContext.getRenderingContext().getServletRequest().getParameter(IBY_INSTRID):pageContext.getRenderingContext().getServletRequest().getParameter(IBY_INSTRUMENT_ID);
      String pmType =  (String)pageContext.getRenderingContext().getServletRequest().getParameter(IBY_INSTRUMENT_TYPE);
      String cardType =  (String)pageContext.getRenderingContext().getServletRequest().getParameter(XXBT_CARD_TYPE);
      String r12RefId =  (String)pageContext.getRenderingContext().getServletRequest().getParameter(R12_REF_ID);
      String r12RefSource =  (String)pageContext.getRenderingContext().getServletRequest().getParameter(R12_REF_SOURCE);
      

      if(orgId!=null)pageContext.putTransactionValue("XXBT_ORG_ID", orgId);      
      if(partyId!=null)pageContext.putTransactionValue("XXBT_PARTY_ID", partyId);    
      if(partySiteId!=null)pageContext.putTransactionValue("XXBT_PARTY_SITE_ID", partySiteId);    
      if(custAccountId!=null)pageContext.putTransactionValue("XXBT_CUST_ACCOUNT_ID", custAccountId);    
      if(custAccountSiteId!=null)pageContext.putTransactionValue("XXBT_ACCOUNT_SITE_ID", custAccountSiteId);    
      if(custAccountSiteUseId!=null)pageContext.putTransactionValue("XXBT_ACCOUNT_SITE_USE_ID", custAccountSiteUseId);    
      if(pmType!=null)pageContext.putTransactionValue("XXBT_PAYMENT_TYPE", pmType);    
      if(instrumentId!=null)pageContext.putTransactionValue("XXBT_INSTRUMENT_ID", instrumentId);    
      if(cardType!=null)pageContext.putTransactionValue("XXBT_CARD_TYPE", cardType);    
      if(r12RefId!=null)pageContext.putTransactionValue(R12_REF_ID, r12RefId);    
      if(r12RefSource!=null)pageContext.putTransactionValue(R12_REF_SOURCE, r12RefSource);    
      this.debugLog(pageContext,"TRX: adding instrument ID:"+instrumentId);
  }
  
  private String isStandAloneMode(OAPageContext pageContext)
  {
    String standAloneModeVal = (String)pageContext.getTransactionValue(STANDALONE_MODE);  

    if(standAloneModeVal==null){
      standAloneModeVal = pageContext.getRenderingContext().getServletRequest().getParameter(STANDALONE_MODE)==null?"N":pageContext.getRenderingContext().getServletRequest().getParameter(STANDALONE_MODE);      	
      pageContext.putTransactionValue(STANDALONE_MODE,standAloneModeVal.toUpperCase());
    }

    return standAloneModeVal;
  }
  
  private void throwException(String errorMessage, MessageToken amessagetoken[])
  {
    throw new OAException( errorMessage, OAException.ERROR);  
//    String appName =  "XXBT";
//    throw new OAException(appName, errorMessage, amessagetoken, OAException.ERROR, null);  
  }

  private void debugLog(OAPageContext pageContext, String msg){
    if(pageContext.isLoggingEnabled(1))
        pageContext.writeDiagnostics(this, (new StringBuilder()).append("xxbtCreditCardCO:").append(msg).toString(), 1);

/*    CallableStatement call =  null;
    try
    {
      call =  pageContext.getRootApplicationModule().getOADBTransaction().getJdbcConnection().prepareCall(""+
            "BEGIN" + 
            "  XXTST_DEBUG(" + 
            "    P_MSG1 => '"+msg+"'" + 
            "  );" + 
            "END; ");
      call.execute();
    } catch (Exception ex)
    {
      ex.printStackTrace();
    }
    finally{
        try{call.close();} catch (Exception ex){ex.printStackTrace();}
    } */
  }

  private void listPageContextParams(OAPageContext pageContext, String prefix)
  {
      Enumeration enums = pageContext.getParameterNames();       
      debugLog(pageContext,"-------------------------------------///"+prefix+"----------------------");
        while(enums.hasMoreElements()){
            String param = (String) enums.nextElement();
            debugLog(pageContext,prefix+":"+param+" - "+ pageContext.getParameter(param) );
        }    
     debugLog(pageContext,"-------------------------------------"+prefix+"///----------------------");
   }
   public void fwdOnSuccess(OAPageContext pageContext, OAWebBean webBean)
   {
     MessageToken[] tokens = { new MessageToken(null,null)};
     OAException mainMessage = new OAException("AR", "AR_UPDATE_CONFIRM", tokens);

     OADialogPage dialogPage = new OADialogPage(OAException.CONFIRMATION, mainMessage, null, null , null);

     dialogPage.setPostToCallingPage(false);

     pageContext.redirectToDialogPage(dialogPage);   
   }

}
